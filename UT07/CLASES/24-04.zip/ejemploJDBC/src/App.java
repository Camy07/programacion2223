import java.io.*;
import java.sql.*;
import java.util.Scanner;

import controlador.Publicaciones;

class App {
    public static void main(String[] args) throws Exception {
        
        System.out.println("Iniciando aplicación...");
        
        Publicaciones biblioteca = new Publicaciones();
        Scanner sc = new Scanner(System.in);

        System.out.print("Escribe el id a buscar: ");
        int id = Integer.parseInt(sc.nextLine());
        System.out.println(biblioteca.buscarPorId(id));


        System.out.print("Escribe el titulo a buscar: ");
        String titulo = sc.nextLine();

        var resultado = biblioteca.buscarPorTitulo(titulo);

        if (resultado.size()>0) {
            System.out.println("Encontrados " + 
                resultado.size() + 
                " resultados:");
            for (String libro : resultado) {
                System.out.println(libro);
            }
        }
        else {
            System.out.println("No se encontró ningún resultado");
        }

        
    }
}